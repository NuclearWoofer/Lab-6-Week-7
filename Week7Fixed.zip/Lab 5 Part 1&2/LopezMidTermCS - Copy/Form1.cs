﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LopezMidTermCS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lblFeedback.Text = "";

            PersonV2 temp = new PersonV2();

            temp.FName = txtFirst.Text;
            temp.MName = txtMiddle.Text;
            temp.LName = txtLast.Text;
            temp.Street1 = txtS1.Text;
            temp.Street2 = txtS2.Text;
            temp.City = txtCity.Text;
            temp.State = txtState.Text;
            temp.Zip = txtZip.Text;
            temp.Phone = txtPhone.Text;
            temp.Email = txtEmail.Text;
            temp.InstaURL = txtInsta.Text;
            temp.CellPhone = txtCell.Text;





            //STATE INITIAL CATCH
            String iniState;
            iniState = txtState.Text;
            if (iniState.Length > 2)
            {
                temp.Feedback = "ERROR: Please enter state initials. EX. [RI]";
            }

            //ZIP CODE ERROR
            string iniZip;
            iniZip = txtZip.Text;
            if (iniZip.Length > 5)
            {
                temp.Feedback = "ERROR: Please enter a five digit zip code only. EX: [02909]";
            }

            //PHONE ERROR
            string iniPhone;
            iniPhone = txtPhone.Text;
            if (iniPhone.Length > 10)
            {
                temp.Feedback = "ERROR: Please Input Proper 10-Digit Phone Number.. Ex. [1234567890]";
            }

            //ERROR CATCHING
            if (!temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.AddARecord(); //if no errors, execute order 66

            }
            else
            {
                lblFeedback.Text = temp.Feedback; //display the err msg.

            }
        }

    }
}
