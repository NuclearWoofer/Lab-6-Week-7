﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;



namespace LopezMidTermCS
{
    class PersonV2 : Person //Inheritance of Person
    {
        //New Additions 
        private string instaURL;
        private string cellPhone;

        public string InstaURL
        {
            get
            {
                return instaURL;
            }
            set
            {
                instaURL = value;

            }
        }

        public string CellPhone
        {
            get
            {
                Int64 cellNumber = Int64.Parse(cellPhone);
                return cellPhone;
            }
            set
            {
                cellPhone = value;
            }

        }



        //CONNECTING DB
        public string AddARecord()
        {
            //init string var
            string strResult = "";
            //making as connection
            SqlConnection Conn = new SqlConnection();
            //initializing its properties
            Conn.ConnectionString = @"Server=sql.neit.edu\sqlstudentserver, 4500;Database=SE245_MLopez;User Id=SE245_MLopez;Password=008008619;";
            string strSQL = "INSERT INTO PersonV2 (FirstName, LastName, MiddleName, Street1, Street2, City, State, ZipCode, Phone, Email, Instagram) VALUES (@FirstName, @LastName, @MiddleName, @Street1, @Street2, @City, @State, @ZipCode, @Phone, @Email, @Instagram)";
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Conn;

            comm.Parameters.AddWithValue("@FirstName", FName);
            comm.Parameters.AddWithValue("@LastName", LName);
            comm.Parameters.AddWithValue("@MiddleName", MName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@ZipCode", Zip);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("Instagram", InstaURL);







            //attempt to connect to the server
            try
            {

                Conn.Open();
                // Open connection to DB
                int intRecs = comm.ExecuteNonQuery();
                strResult = $"SUCCESS: Inserted {intRecs} records.";
                //Report that we made the connection and added a record

                Conn.Close();
            }
            catch(Exception err)
            {
                //If we got here, there was a problem connecting to DB
                strResult = "ERROR: " + err.Message;
                //Set feedback to state there was an error & error info
            }
            finally
            {

            }
            //Return resulting feedback string
            return strResult;

        }

        public PersonV2() : base()
        {
            cellPhone = "";
            instaURL = "";

        }

    }
}
