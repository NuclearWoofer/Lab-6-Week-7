﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LopezMidTermCS
{
    class Person
    {
        //person struct initiated
        private string fName;
        private string lName;
        private string mName;
        private string street1;
        private string street2;
        private string city;
        private string state;
        private string zipCode;
        private string phoneNumber; //edited for part two - numbers only
        private string email;
        public string Feedback = "";

        public string FName
        {
            get
            {
                return fName;
            }
            set
            {
                if (BasicValidation.GotBadWords(value))
                {
                    fName = value;
                }
                else
                {
                    fName = value;
                }
            }
        }
        public string LName
        {
            get
            {
                return lName;
            }
            set
            {
                lName = value;
            }
        }
        public string MName
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }
        public string Street1
        {
            get
            {
                return street1;
            }
            set
            {
                street1 = value;
            }
        }
        public string Street2
        {
            get
            {
                return street2;
            }
            set
            {
                street2 = value;
            }
        }
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }
        public string State
        {
            get
            {
                return state;
            }
            set
            {
                state = value;
            }
        }
        public string Zip
        {
            get
            {
                
                return zipCode;
            }
            set
            {
                zipCode = value;
            }
        }
        public string Phone
        {
            get
            {

                return phoneNumber;
            }
            set
            {
                phoneNumber = value;
            }
        }
        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                if (BasicValidation.IsValidEmail(value))
                {
                    email = value;
                }
                else
                {
                    email = "INVALID";
                }
            }

        }

        public Person()
        {
            fName = "";
            mName = "";
            lName = "";
            street1 = "";
            street2 = "";
            city = "";
            state = "";
            zipCode = "";
            phoneNumber = "";
            email = "";

        }

    }
}

